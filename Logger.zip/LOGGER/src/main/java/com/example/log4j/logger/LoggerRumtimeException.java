package com.example.log4j.logger;

import org.apache.log4j.Logger;

public class LoggerRumtimeException {
	
	final static  Logger logger=Logger.getLogger(LoggerRumtimeException.class);
	
	private void divide(){
		int i=10/0;	
	}
	
	public static void main(String[] args){
	   LoggerRumtimeException lre=new LoggerRumtimeException();
		
		try{	
		   lre.divide();
	   }catch(ArithmeticException ae){
		   logger.error("sorry something went wrong!"+ae);
		   ae.printStackTrace();
	   }
	}

}
